#ifndef __SYS_VM86_H
#define __SYS_VM86_H
#include <features.h>
#include __SYSINC__(vm86.h)
#endif
