#ifndef __SYS_UTSNAME_H
#define __SYS_UTSNAME_H

#include <features.h>
#include <sys/param.h>
#include __SYSINC__(utsname.h)

#endif
