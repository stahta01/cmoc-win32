

nosound()
{
}

sound(freq)
int freq
{
}
