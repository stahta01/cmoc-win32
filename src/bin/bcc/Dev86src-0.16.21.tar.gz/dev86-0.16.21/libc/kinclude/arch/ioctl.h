/*
 *	Nothing here yet.
 */

#ifndef __ARCH_8086_IOCTL_H
#define __ARCH_8086_IOCTL_H


#endif /* __ARCH_8086_IOCTL_H */
