/*
** defn for getopt
*/

extern  int  optind, opterr;
extern  char *optarg;
