char	*memccpy();
char	*memchr();
int	memcmp();
char	*memcpy();
char	*memset();
