extern int errno;

float    atof();
int      atoi();
long     atol();
char     *itoa();
char     *ltoa();
char     *utoa();
int      htoi();
long     htol();
int      max();
int      min();
unsigned umin();
unsigned umax();
char     *calloc();
char     *malloc();
char     *realloc();
/*
void     free();
*/
