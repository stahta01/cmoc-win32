/*
** definitions for "debug trace"
*/

#define  TROFF       0
#define  TRON        1
#define  E_INTERACT  2
#define  L_INTERACT  4
