char  *strcat();
char  *strncat();
char  *strhcpy();
char  *strcpy();
char  *strncpy();
char  *strclr();
char  *strucat();
char  *strucpy();
char  *index();
char  *rindex();
char  *reverse();
char  *strend();
int   strcmp();
int   strncmp();
int   strlen();
int   strucmp();
int   strnucmp();
int   patmatch();

char  *strchr();
char  *strrchr();

char  *strspn();
char  *strcspn();
char  *strtok();
char  *strpbrk();
