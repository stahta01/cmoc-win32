double acos(),asin(),atan(),sin(),cos(),tan();
double pow(),sinh(),cosh(),tanh(),asinh(),acosh(),atanh();
double exp(),antilg(),log10(),log();
double trunc(),sqrt(),sqr(),inv();
double dexp(),dabs();
