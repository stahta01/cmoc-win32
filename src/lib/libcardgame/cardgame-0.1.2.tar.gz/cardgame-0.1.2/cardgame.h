/*  cardgame.h - PMODE 4 playing cards library for the CoCo.
    Assumes Disk Basic, i.e., the PMODE 4 screen starts at $0E00.
   
    By Pierre Sarrazin <http://sarrazip.com/>.
    This file is in the public domain.
   
    Version 0.1.0 - 2015-08-12 - First public release.
    Version 0.1.1 - 2016-03-12 - New #defines. New function drawFaceDownCard().
    Version 0.1.2 - 2016-??-?? - setConsoleOutHook() and resetConsoleOutHook()
                                 now taken from <coco.h>.
*/

#ifndef _H_cardgame
#define _H_cardgame


#ifndef _COCO_BASIC_
#error This program must be compiled for a CoCo Disk Basic environment.
#endif

#define NDEBUG  /* disable the asserts */

#include <coco.h>
#include <stdarg.h>
#include "compiled-cards.h"   /* card bitmaps */
#include "8-bit-wide-font.h"  /* text font bitmaps */

#define NULL ((void *) 0)


#ifndef NDEBUG
void restoreOriginalTextMode();
#define assertf(cond, ...) do { if (!(cond)) { \
                        restoreOriginalTextMode(); \
                        printf("***ASSERT FAILED (%s): %u: %s: ", __TIME__, __LINE__, #cond); \
                        printf(__VA_ARGS__); putchar('\n'); \
                        for (;;); } } while (0)
#else
#define assertf(cond, ...) ((void) 0)
#endif

// Standard addresses of 6k PMODE 4 screens. Must be divisible by 512.
// To be put in scrnBuffer.
#define PMODE4_PAGE0            0x0E00
#define PMODE4_PAGE1            (PMODE4_PAGE0 + BYTES_PER_SCREEN)

#define WORDS_PER_SCREEN_ROW    16
#define BYTES_PER_SCREEN_ROW    32
#define TEXT_COLS_PER_ROW       32
#define TEXT_ROWS_PER_SCREEN    24
#define PIXEL_ROWS_PER_SCREEN   192
#define BYTES_PER_SCREEN        0x1800  // 256 * 192 / 8 == 6144 == 6 kB
#define PIXEL_ROWS_PER_GLYPH    7       // see 8-bit-wide-font.h
#define PIXEL_ROWS_PER_TEXT_ROW 8       // PIXEL_ROWS_PER_GLYPH plus one separator row
#define BYTES_PER_TEXT_ROW      256     // 32 bytes per row of pixels, 8 rows of pixels per text row

#define NUMCARDS                54
#define BAD_CARD_SUIT           0xFF
#define BAD_CARD_VALUE          0
#define BAD_INDEX               0xFF

#define ROWS_ABOVE_SUIT 2
#define ROWS_BELOW_SUIT 6
#define ROWS_PER_CARD_TOP 5
#define ROWS_PER_CARD_BOTTOM ROWS_PER_CARD_TOP 
#define BYTES_PER_CARD_WIDTH 4
#define ROWS_PER_CARD_VALUE 10
#define ROWS_PER_SUIT 7

#define SUIT_HEARTS   0
#define SUIT_SPADES   1
#define SUIT_DIAMONDS 2
#define SUIT_CLUBS    3
#define SUIT_JOKER    4
#define SUIT_NONE     255


//#define optDelay(ticks) ((void) 0)
#define optDelay(ticks) delay(ticks)

byte *scrnBuffer;  // 1st PMODE 4 buffer
byte textPosX;  // 0..BYTES_PER_SCREEN_ROW-1
byte textPosY;  // 0..TEXT_ROWS_PER_SCREEN-1
byte initTextMode;
void *oldCHROOT;


///////////////////////////////////////////////////////////////////////////////


// Concatenates one or more strings into an output buffer.
// out: Output buffer.
// max: Maximum number of characters to write to the output buffer,
//      including the terminating '\0'.
//
// CAUTION: The last argument MUST be a null pointer.
//
// If the input strings together contain too many characters,
// the concatenation stops at 'max'.
// The returned string always finishes with a terminating '\0'.
//
void concat(char *out, unsigned max, ...)
{
    va_list ap;
    va_start(ap, max);
    for (char *src; src = va_arg(ap, char *); )  // for each string passed as an argument
    {
        word len = strlen(src);
        if (len > max - 1)
            len = max - 1;
        max -= len;
        while (len--)  // while that string is not finished
            *out++ = *src++;
        if (max <= 1)
            break;
    }
    va_end(ap);
    *out = '\0';
}


///////////////////////////////////////////////////////////////////////////////


// Does NOT scroll the screen when writing to the last screen position.
// Wraps around to home instead.
//
void drawChar(unsigned char c)
{
    if (c < ' ' || c > 'Z')  // mask undefined glyphs
        c = '?';
    
    byte *dest = scrnBuffer + (((word) textPosY) << 8) + textPosX;
    byte *src = eightBitWideFont[c - ' '];
    for (byte i = 0; i < PIXEL_ROWS_PER_GLYPH; ++i)
    {
        *dest = *src++;
        //printf("Byte $%02X at $%04X\n", *src, dest); ++src; 
        dest += BYTES_PER_SCREEN_ROW;
    }
    *dest = 0;  // black row below glyph
    
    // Advance cursor.
    if (textPosX == BYTES_PER_SCREEN_ROW - 1)  // if column finished, go to next row
    {
        textPosX = 0;
        if (textPosY == TEXT_ROWS_PER_SCREEN - 1)  // if at last row, wrap around
            textPosY = 0;  // wrap around
        else
            ++textPosY;
    }
    else
        ++textPosX;
}


// Does nothing if x or y are out of range.
//
void moveCursor(byte x, byte y)
{
    if (x >= BYTES_PER_SCREEN_ROW)
        return;
    if (y >= TEXT_ROWS_PER_SCREEN)
        return;

    textPosX = x;
    textPosY = y;
}

// Called by PUTCHR, which is called by printf() et al.
// The character to print is in A.
// It is sent to drawChar() (the 32x24 screen) instead of
// the regular CoCo screen.
//
void hiResTextConsoleOutHook()
{
    byte ch;
    asm
    {
        pshs    x,b                        // avoids crashing...
        sta     ch
    }
    
    if (ch == '\r')
        ch = '\n';
    else
        ch = (byte) toupper(ch);

    drawChar(ch);

    asm
    {
        puls    b,x
    }
}


// row: Text line where to print (2nd argument to moveCursor()).
//      Must not be more than 'textScreenWidth' characters.
// Returns the text column where 'str' gets printed. 
//
byte printCentered(byte row, char *str)
{
    word len = strlen(str);
    if (len > textScreenWidth)
        len = textScreenWidth;
    byte col = (byte) (textScreenWidth - len) >> 1;
    moveCursor(0, row);
    for (byte x = 0; x < col; ++x)
        putchar(' '); 
    putstr(str, len);
    for (byte x = col; x < BYTES_PER_SCREEN_ROW; ++x)
        putchar(' ');
    return col;
}


void restoreOriginalTextMode()
{
    setConsoleOutHook(oldCHROOT);

    showLowResTextAddress();
    showPmode0();
    width(initTextMode);
    cls(255);
}


// byteOffset: Offset in bytes from the left of the screen (must be < BYTES_PER_SCREEN_ROW).
// pixelRow: Vertical position (in pixels) of the row at which to start drawing (downwards).
//           Must be < PIXEL_ROWS_PER_SCREEN.
// numRows: Must be > 0.
// rowRepetitions: Must be > 0.
// Returns the address of the top left byte of the region that was modified.
// Uses scrnBuffer as the start of the PMODE 4 screen buffer.
//
byte *drawCompiledPixMap(byte byteOffset, byte pixelRow, word *wordArray, byte numRows, byte rowRepetitions)
{
    assertf(byteOffset < BYTES_PER_SCREEN_ROW, "%u", byteOffset);
    assertf(pixelRow < PIXEL_ROWS_PER_SCREEN, "%u", pixelRow);
    assertf(numRows <= PIXEL_ROWS_PER_SCREEN, "%u", numRows);
    assertf(pixelRow + numRows <= PIXEL_ROWS_PER_SCREEN, "%u, %u", pixelRow, numRows);
    assertf(rowRepetitions > 0, "%u", rowRepetitions);
    
    /*  Logic implemented in assembly language that follows:
    word *dest = (word *) (scrnBuffer + (word) pixelRow * BYTES_PER_SCREEN_ROW + byteOffset);
    for (byte i = 0; i < numRows; ++i)
    {
        word w = wordArray[i];
        for (byte r = 0; r < rowRepetitions; ++r)
        {
            *dest = w;
            dest += WORDS_PER_SCREEN_ROW;
        }
    }
    */
    
    byte *topLeft;
    byte r;  // temp row counter
    
    asm
    {
        pshs    y           // per CMOC convention               

        lda     pixelRow
        ldb     #BYTES_PER_SCREEN_ROW
        mul
        addb    byteOffset
        adca    #0
        addd    scrnBuffer
        tfr     d,x         // make X point to first screen byte to write to
        stx     topLeft
        
        ldy     wordArray

drawCompiledPixMap_foreach_word:
        ldb     rowRepetitions  // reinit rep counter
        stb     r
        ldd     ,y++
drawCompiledPixMap_foreach_rep:
        std     ,x
        leax    BYTES_PER_SCREEN_ROW,x  // move to next row down
        
        dec     r
        bne     drawCompiledPixMap_foreach_rep
        
        dec     numRows
        bne     drawCompiledPixMap_foreach_word
        
        puls    y
    }
    
    return topLeft;
}


// cardValue: 1..13 (1 = ace).
// cardSuit: SUIT_* (0..3).
// Except for jokers: cardValue must be 1 (red) or 2 (black) and cardSuit must be SUIT_JOKER.
// byteColumn: 0..28 (maps to pixel columns 0, 8, 16, ..., 224).
// pixelRow: 0..150.
//
// The number of pixels rows occupied by the card is given by getNumPixelRowsPerCard().
// A card is 4 bytes wide, i.e., 32 pixels.
//
void drawCompiledCard(byte cardValue, byte cardSuit, byte byteColumn, byte pixelRow)
{
    --cardValue;  // bring to 0..12 index
    
    // Draw top of card.
    drawCompiledPixMap(byteColumn,     pixelRow, cardTopLeft,  ROWS_PER_CARD_TOP, 1);
    drawCompiledPixMap(byteColumn + 2, pixelRow, cardTopRight, ROWS_PER_CARD_TOP, 1);
    drawCompiledPixMap(byteColumn + 2, pixelRow + ROWS_PER_CARD_TOP, cardRight, 1, ROWS_PER_CARD_TOP * 2);

    // Draw card value (A, 2..10, J, Q, K, joker).
    word *pixmap;
    if (cardSuit == SUIT_JOKER)
        pixmap = (cardValue == 1 ? redJokerValue : blackJokerValue);
    else
        pixmap = (word *) ((cardSuit & 1) ? blackCards[cardValue] : redCards[cardValue]);

    drawCompiledPixMap(byteColumn, pixelRow + ROWS_PER_CARD_TOP, pixmap, ROWS_PER_CARD_VALUE, 1);

    // Draw blank middle (the suit will be drawn over it).
    byte middleRow = pixelRow + ROWS_PER_CARD_TOP + ROWS_PER_CARD_VALUE;
    byte middleHeight = ROWS_ABOVE_SUIT + ROWS_PER_SUIT * 2 + ROWS_BELOW_SUIT; 
    drawCompiledPixMap(byteColumn,     middleRow, cardLeft,  1, middleHeight);
    drawCompiledPixMap(byteColumn + 2, middleRow, cardRight, 1, middleHeight);
    
    // Draw bottom of card.
    drawCompiledPixMap(byteColumn,     middleRow + middleHeight, cardBottomLeft,  ROWS_PER_CARD_BOTTOM, 1);
    drawCompiledPixMap(byteColumn + 2, middleRow + middleHeight, cardBottomRight, ROWS_PER_CARD_BOTTOM, 1);

    // Draw suit.
    byte suitByteOffset = byteColumn + 1;
    byte suitRow        = pixelRow + ROWS_PER_CARD_TOP + ROWS_ABOVE_SUIT + ROWS_PER_CARD_VALUE;
    if (cardSuit == SUIT_JOKER)
        drawCompiledPixMap(suitByteOffset, suitRow, cardValue == 1 ? redJokerSuit : blackJokerSuit, ROWS_PER_SUIT, 2);
    else
        drawCompiledPixMap(suitByteOffset, suitRow, suits[cardSuit], ROWS_PER_SUIT, 2);
}


// Height of a card drawn by drawCompiledCard().
// A card is 4 bytes wide, i.e., 32 pixels.
//
byte getNumPixelRowsPerCard()
{
    return ROWS_PER_CARD_TOP + ROWS_PER_CARD_VALUE + ROWS_ABOVE_SUIT
           + ROWS_PER_SUIT * 2 + ROWS_BELOW_SUIT + ROWS_PER_CARD_BOTTOM;
}


void eraseCard(byte byteColumn, byte pixelRow)
{
    word *p = (word *) (scrnBuffer + (((word) pixelRow) << 5) + byteColumn);
    byte h = getNumPixelRowsPerCard();
    for (byte i = 0; i < h; ++i, p += WORDS_PER_SCREEN_ROW)
    {
        p[0] = 0;
        p[1] = 0;
    }
}


// rowInPixels: Offset in pixels down the top of the screen.
// colInBytes: Horizontal position of the card, in bytes (0..28).
//
void drawFaceDownCard(byte rowInPixels, byte colInBytes)
{
    word *writer = (word *) (scrnBuffer + (word) rowInPixels * BYTES_PER_SCREEN_ROW + colInBytes);
    byte rowsPerCard = getNumPixelRowsPerCard();
    word wordToWrite = 0x5555;
    for (byte row = 0; row < rowsPerCard; ++row, writer += WORDS_PER_SCREEN_ROW)
    {
        *writer = writer[1] = wordToWrite;  // blue
        if (row == rowsPerCard - 2)
            wordToWrite = 0x5555;
        else if (row & 1)
            wordToWrite = 0x0505;
        else
            wordToWrite = 0x5050;
    }
}


byte getCardType(byte card)
{
    if (card <= 13)
        return SUIT_HEARTS;
    if (card <= 26)
        return SUIT_SPADES;
    if (card <= 39)
        return SUIT_DIAMONDS;
    if (card <= 52)
        return SUIT_CLUBS;
    if (card <= 54)
        return SUIT_JOKER;
    return BAD_CARD_SUIT;
}


byte getCardValue(byte card)
{
    if (card == 0)
        return BAD_CARD_VALUE;
    if (card <= 52)
        return (card - 1) % 13 + 1;
    if (card <= 54)
        return card - 52;
    return BAD_CARD_VALUE;
}


char *getSuitName(byte suit)
{
    switch (suit)
    {
        case SUIT_HEARTS:   return "hearts";
        case SUIT_SPADES:   return "spades";
        case SUIT_DIAMONDS: return "diamonds";
        case SUIT_CLUBS:    return "clubs";
        default:            return "ERROR";           
    }
}


void shuffleDeck(byte deck[], byte numCards)
{
    for (byte i = 1; i < numCards; ++i)
    {
        byte other = (byte) (rand() % (numCards - i) + i);
        assertf(i - 1 < NUMCARDS, "%u", i);
        assertf(other < NUMCARDS, "%u", other);
        byte temp = deck[i - 1];
        deck[i - 1] = deck[other];
        deck[other] = temp;
    }
}


// Removes a card from the end of the designated deck, which
// initially contains a number of cards given by *pNumCards,
// decrements this number, then returns the removed card.
// (The "top" of a deck is at the highest valid index,
// while the "bottom" is at index 0.)
//
byte pickCardFromDeck(byte deck[], byte *pNumCards)
{
    if (*pNumCards == 0)
        return BAD_CARD_VALUE;
    byte card = deck[--*pNumCards];
    assertf(card >= 1 && card <= NUMCARDS, "%u", card);
    return card;
}


// col: Byte offset in targeted row.
// row: Pixel row where to draw top of suit.
// suit: Index into suits[].
//
void drawSuit(byte col, byte row, byte suit)
{
    byte *topLeft = drawCompiledPixMap(col, row, suits[suit], ROWS_PER_SUIT, 2);
    
    // Draw a white horizontal line above and below the suit pixmap just drawn at topLeft:
    //
    byte *aboveRow = topLeft - BYTES_PER_SCREEN_ROW;
    *((word *) aboveRow) = 0xFFFF;
    *((word *) topLeft + (ROWS_PER_SUIT << 5)) = 0xFFFF;
    
    // Draw a white vertical line at the left of that pixmap:
    //
    byte *leftSide = aboveRow - 1;
    for (byte numRows = (ROWS_PER_SUIT << 1) + 2; numRows; --numRows, leftSide += BYTES_PER_SCREEN_ROW)
        *leftSide |= 0x01;
}


// Initializes CoCo support functions.
// Goes to PMODE 4, with the 6k buffer at the address given by
// _scrnBuffer, which is typically 0x0E00 under Disk Basic.
// Global variable scrnBuffer is initialized with _scrnBuffer.
// Initializes the 32x24 software text screen's cursor at the home position.
// Remembers the initial text mode (32, 40, 80).
// Initializes globals textScreenWidth and textScreenHeight.
// Redirects printf() so that it prints to the software text screen.
//
// Call closeCardGameScreenMode() to go back to text mode.
//
void openCardGameScreenMode(void *_scrnBuffer)
{
    initCoCoSupport();

    scrnBuffer = (byte *) _scrnBuffer;
    initTextMode = getTextMode();  // for restoreOriginalTextMode()
    width(32);
    pcls(scrnBuffer, 0);
    showGraphicsAddress((byte) (scrnBuffer >> 9));  // set SAM registers to show PMODE 4 at scrnBuffer
    showPmode4(1);  // white/black
    
    // Hi-res text screen:
    moveCursor(0, 0);
    
    // Set screen dimensions for functions in coco.h.
    textScreenWidth  = BYTES_PER_SCREEN_ROW;
    textScreenHeight = TEXT_ROWS_PER_SCREEN;

    // Redirect printf().
    oldCHROOT = setConsoleOutHook(hiResTextConsoleOutHook);
}


void closeCardGameScreenMode()
{
    restoreOriginalTextMode();
}


#endif  /* _H_cardgame */
