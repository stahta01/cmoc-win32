// varptr.c - Accessing Basic program variables from a CMOC-compiled program.
//
// To be used with VARPTR.BAS, a Basic program that defined several variables
// whose values are displayed by this CMOC-compilable program.
//
// This demo requires a 32k CoCo because of the quantity of variables
// the Basic program creates.
//
// By Pierre Sarrazin <http://sarrazip.com>
// Version 2016-08-21.
// This file is in the public domain.
//
// CMOC Home Page: http://sarrazip.com/dev/cmoc.html
//
// Representation of simple (non-array) variable:
//
// Bytes 0 and 1 are the variable name. Byte 1 is 0 or 0x80 if the
// name has only one letter. Bit 7 of byte 1 is set for a string variable.
// If the variable is numeric, bytes 2..6 are a packed floating point value
// in a format similar to IEEE 754.
// If the variable is a string, byte 2 is the length and bytes 4 and 5
// are the address of the contents (if length > 0).

// Address where this program gets loaded by default.
//
#pragma org 0x6C00


#include <coco.h>


// Useful Color Basic addresses.
//
enum
{
    TXTTAB = 0x0019,	// beginning of Basic program
    VARTAB = 0x001B,	// start of variables
    ARYTAB = 0x001D,	// start of arrays
    ARYEND = 0x001F,	// end of arrays
    FRETOP = 0x0021,    // start of string storage
    MEMSIZ = 0x0027,    // top of string space
};


word getSpaceUsedByProgram()
{
    return * (char **) VARTAB - * (char **) TXTTAB;
}


word getSpaceUsedBySimpleVariables()
{
    return * (char **) ARYTAB - * (char **) VARTAB;
}


word getSpaceUsedByArrayVariables()
{
    return * (char **) ARYEND - * (char **) ARYTAB;
}


word getSpaceReservedForStrings()
{
    return * (char **) MEMSIZ - * (char **) FRETOP;
}


// Returns the address of the 5-byte descriptor of the named variable,
// or a null pointer if the variable is not defined.
// name: C string designating the targeted variable, e.g., "A", "AB".
//       This string must be null-terminated.
// isString: Non-zero means to look for a string variable; zero means
//           a numerical variable.
// A null pointer is returned if the variable is not found.
// See also: getStringContents(), getWordVariableValue().
//
void *findSimpleVariable(char *name, byte isString)
{
    char secondNameChar = name[1] | (isString ? 0x80 : 0x00);
    char *varStart = * (char **) VARTAB;
    char *arrayStart = * (char **) ARYTAB;
    for (char *p = varStart; p < arrayStart; p += 7)
	if (p[0] == name[0] && p[1] == secondNameChar)
	    return (void *) (p + 2);  // success
    return 0;  // fail
}


// Similar to findSimpleVariable(), but only searches the array variables.
// A null pointer is returned if the variable is not found.
// See also: getArrayNumberOfDimension(), getArrayDimensions(), getArrayElement().
//
void *findArrayVariable(char *name, byte isString)
{
    char secondNameChar = name[1] | (isString ? 0x80 : 0x00);
    char *arrayStart = * (char **) ARYTAB;
    char *arrayEnd   = * (char **) ARYEND;
    for (char *p = arrayStart; p < arrayEnd; )
    {
	if (p[0] == name[0] && p[1] == secondNameChar)
	    return (void *) (p + 4);  // success: point past offset word
	p += * (word *) (p + 2);  // word after 2-byte name is offset to next array
    }

    return 0;  // fail
}


// Returns the number of dimensions in an array found by findArrayVariable().
//
byte getArrayNumberOfDimension(void *arrayStorage)
{
    return * (byte *) arrayStorage;
}


// Returns size of each dimension of an array found by findArrayVariable().
// The number of dimensions should be obtained from getArrayNumberOfDimension().
//
void getArrayDimensions(void *arrayStorage, word dimArray[])
{
    byte numDims = * (byte *) arrayStorage;
    memcpy(dimArray, ((byte *) arrayStorage) + 1, (word) numDims * 2);
}


// Returns the address of an element of an array found by findArrayVariable().
//
// Example: To get Basic array element A(3,5,7), do this:
//          void *a = findArrayVariable("A", FALSE);
//          if (a) {
//              word indices[] = { 3, 5, 7 };
//              void *elementStorage = getArrayElement(a, indices);
//          }
//
// Based on Color Basic routines at $B404 and $B4A0.
//
void *getArrayElement(void *arrayStorage, word indexArray[])
{
    byte numDims = * (byte *) arrayStorage;
    byte *dimArrayEnd = (byte *) arrayStorage + 1 + (word) numDims * 2;
    word *lastDim = (word *) (dimArrayEnd - 2);
    word elementOffset = 0;  // in elements, not in bytes
    byte indexIndex = 0;
    word factor = 1;
    do
    {
	elementOffset += indexArray[indexIndex] * factor;
	factor *= lastDim[- indexIndex];
    } while (++indexIndex < numDims);

    return (void *) (dimArrayEnd + elementOffset * 5);
}


// Returns the integer part of a numerical variable's value.
// If the variable exists, its ABSOLUTE value is stored in *value,
// its sign is stored in *isNegative (non-zero means negative), and
// 0 is returned.
// Returns -1 if the variable is not found.
// Returns -2 if the variable's value does not fit in 16 bits.
//
char getWordVariableValue(char *name, word *absValue, byte *isNegative)
{
    byte *desc = (byte *) findSimpleVariable(name, FALSE);
    if (!desc)
	return -1;
    if (desc[0] == 0)
    {
	*absValue = 0;
	*isNegative = 0;
	return 0;
    }
    byte exponent = desc[0] & 0x7F;
    if (exponent > 16)
	return -2;

    *isNegative = desc[1] & 0x80;
    *absValue = ((* (word *) (desc + 1)) | 0x8000) >> (16 - exponent);
    return 0;
}


//FIXME: doc
char setVariableValueToWord(char *name, word newAbsValue, byte isNegative)
{
    byte *desc = (byte *) findSimpleVariable(name, FALSE);
    //printf("SET(%s, %u, %u): %p\n", name, newAbsValue, isNegative, desc);
    if (!desc)
	return -1;

    if (newAbsValue == 0)
    {
	desc[0] = 0;
	* (word *) (desc + 1) = 0;
	* (word *) (desc + 3) = 0;
    }
    else
    {
	// Bring highest set bit of newAbsValue to bit 15.
	byte exponent = 0x80 + 8 * sizeof(word);
	while ((newAbsValue & 0x8000) == 0)
	{
	    newAbsValue <<= 1;
	    --exponent;
	}
	newAbsValue &= 0x7FFF;  // bit 15 will be the sign bit in the IEEE 754 format
	if (isNegative)
	    newAbsValue |= 0x8000;

	desc[0] = exponent;
	* (word *) (desc + 1) = newAbsValue;
	* (word *) (desc + 3) = 0;
    }

    //printf("%02x %02x %02x %02x %02x\n", desc[0], desc[1], desc[2], desc[3], desc[4]);
    return 0;
}


// Returns the address and the length of a string variable stored
// at the given address.
//
// CAUTION: If the string variable was initialized by a Basic READ statement,
//          then its content pointer points to a string in a DATA statement.
//          If the content is modified, the program's DATA statement is modified.
//          If the Basic is run a second time after this, it will not READ the
//          same data as the first time.
//
byte getStringContents(void *variableStorage, char **contents)
{
    *contents = * (char **) (variableStorage + 2);
    return ((byte *) variableStorage)[0];
}


// Returns the address and length of the named string variable,
// or a null pointer and zero length if the variable is not defined.
// Example:
//   char *contents;
//   byte length = getStringVariableContents("A", &contents);  // A$
//   if (contents) {  // if A$ is defined
//       putstr(contents, length);  // print A$
//       memset(contents, '*', length);  // fill A$ with asterisks
//   }
//
byte getStringVariableContents(char *name, char **contents)
{
    byte *desc = (byte *) findSimpleVariable(name, TRUE);
    if (!desc)
    {
	*contents = 0;
	return 0;
    }
    return getStringContents(desc, contents);
}


///////////////////////////////////////////////////////////////////////////////
//
// DEMONSTRATION
//
///////////////////////////////////////////////////////////////////////////////


void pause()
{
    printf("--MORE--");
    byte c = waitkey(TRUE);
    putchar('\n');
    if (c == 'Q')
	exit(0);
}


void _printAddress(char *label, word *addressPtr)
{
    printf("%s = %p\n", label, *addressPtr);
}


#define printAddress(label) _printAddress(#label, (word *) label)


int main()
{
    initCoCoSupport();

    cls(255);
    printf(" DEMO OF BASIC VARIABLE ACCESS\n"
           "      FROM A CMOC PROGRAM     \n"
	   "\n");

    char *varNames[] = { "A", "AB", "A1" };
    for (byte i = 0; i < sizeof(varNames) / sizeof(varNames[0]); ++i)
    {
	// Look up varNames[i] as a numerical variable.
	word value;
	byte sign;
	char code = getWordVariableValue(varNames[i], &value, &sign);
	switch (code)
	{
	case 0:
	    printf("%s=%s%u\n", varNames[i], sign ? "-" : "", value);

	    // Change the value to minus 'i'.
	    setVariableValueToWord(varNames[i], i, TRUE);
	    break;
	case -1:
	    printf("%s NOT DEFINED\n", varNames[i]);
	    break;
	case -2:
	    printf("%s OUT OF RANGE\n", varNames[i]);
	    break;
	default:
	    printf("%s: UNEXPECTED ERROR\n", varNames[i]);
	}

	// Note that using the variable's floating point value is
	// possible but would require interpreting the IEEE 754
	// format or calling Color Basic's floating point routines.

	// Look up varNames[i] as a string variable.
	char *contents;
	byte length = getStringVariableContents(varNames[i], &contents);
	if (contents)
	{
	    printf("%s$=\"", varNames[i]);
	    putstr(contents, length);
	    printf("\" (%u BYTES AT %p)\n", length, contents);
	}
	else
	    printf("%s$ NOT DEFINED\n", varNames[i]);
    }

    pause();

    printf("ARRAY A:\n");
    void *arrayStorage = findArrayVariable("A", TRUE);
    if (!arrayStorage)
	printf("NOT DEFINED\n");
    else
    {
	byte numDims = getArrayNumberOfDimension(arrayStorage);
	printf("%u DIMENSION(S): ", numDims);
	if (numDims == 2)
	{
	    word dims[2];
	    getArrayDimensions(arrayStorage, dims);
	    for (byte i = 2; i--; )
		printf("%u ", dims[i]);
	    printf("\n");
	    for (word j = 0; j <= 3; ++j)
	    {
		for (word i = 0; i <= 2; ++i)
		{
		    printf("A$=(%u,%u)", i, j);
		    word indexArray[] = { i, j };
		    void *elementStorage = getArrayElement(arrayStorage, indexArray);
		    char *contents;
		    byte length = getStringContents(elementStorage, &contents);
		    if (contents)
		    {
			printf("=\"");
			putstr(contents, length);
			printf("\"\n");
		    }
		    else
			printf(" NOT DEFINED\n");
		}
	    }
	}
	else
	{
	    printf("UNEXPECTED\n");
	}
    }

    pause();

    printf("ARRAY B:\n");
    arrayStorage = findArrayVariable("B", TRUE);
    if (!arrayStorage)
	printf("NOT DEFINED\n");
    else
    {
	byte numDims = getArrayNumberOfDimension(arrayStorage);
	printf("%u DIMENSION(S): ", numDims);
	if (numDims == 3)
	{
	    word dims[3];
	    getArrayDimensions(arrayStorage, dims);
	    for (byte i = 3; i--; )
		printf("%u ", dims[i]);
	    printf("\n");
	    for (word k = 0; k <= 1; ++k)
	    {
		for (word j = 0; j <= 3; ++j)
		{
		    for (word i = 0; i <= 2; ++i)
		    {
			printf("B$(%u,%u,%u)", i, j, k);
			word indexArray[] = { i, j, k };
			void *elementStorage = getArrayElement(arrayStorage, indexArray);
			char *contents;
			byte length = getStringContents(elementStorage, &contents);
			if (contents)
			{
			    printf("=\"");
			    putstr(contents, length);
			    printf("\"\n");
			}
			else
			    printf(" NOT DEFINED\n");
		    }
		}
		if (k == 0)
		    pause();
	    }
	}
	else
	{
	    printf("UNEXPECTED\n");
	}
    }

    pause();

    printAddress(TXTTAB);
    printAddress(VARTAB);
    printAddress(ARYTAB);
    printAddress(ARYEND);
    printAddress(FRETOP);
    printAddress(MEMSIZ);

    printf("%4u BYTES FOR THE PROGRAM.\n"
           "%4u FOR SIMPLE VARIABLES.\n"
           "%4u FOR ARRAY VARIABLES.\n"
           "%4u RESERVED FOR STRINGS.\n",
		getSpaceUsedByProgram(),
		getSpaceUsedBySimpleVariables(),
		getSpaceUsedByArrayVariables(),
		getSpaceReservedForStrings());

    pause();

    return 0;
}
